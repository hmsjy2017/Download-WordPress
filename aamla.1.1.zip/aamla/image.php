<?php
/**
 * The template for displaying image attachments
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Aamla
 * @since 1.0.0
 */

get_template_part( 'index' );
