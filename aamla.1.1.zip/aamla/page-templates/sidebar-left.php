<?php
/**
 * Template Name: Sidebar Left
 * Template Post Type: post, page
 *
 * The custom page template file to change content sidebar layout.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Aamla
 * @since 1.0.0
 */

get_template_part( 'index' );
