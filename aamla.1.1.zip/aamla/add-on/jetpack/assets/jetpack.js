(function( $ ) {
	$(document.body).on("post-load", function() {
		aamlaMediaManager();
	});
}( jQuery ));
